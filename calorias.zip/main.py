print("how many calories you need to consume every day to have a healty life")
ques = str(input("Are you a man or a woman(put M for man and W for woman)? "))
h = int(input("What is your height in centimeters(only put the number)?"))
w = float(input("What is your weight in kilogram(only put the number)?"))
o = int(input("How old are you(only put the number)?"))
print("Are you") 
print("- Sedentary (little or no exercise), ")
print("- Lightly active (exercise 1–3 days/week), ")
print("- Moderately active (exercise 3–5 days/week), ")
print("- Active (exercise 6–7 days/week), ")
print("- Very active (hard exercise 6–7 days/week)")
d = input("put only the first letter in capslock, for exemple if your sedentary write only the letter s in capslock (S)")
if ques == "W":
  mma = 655.1 + (9.563 * w) + (1.850 * h) - (4.676 * o)
  if d == "S":
    bo = mma + 1.2
    print("you need to consume", bo, "per day")
  elif d == "L":
    ba = mma + 1.375
    print("you need to consume", ba, "per day")
  elif d == "M":
    be = mma + 1.55
    print("you need to consume", be, "per day")
  elif d == "A":
    bi = mma + 1.725
    print("you need to consume", bi, "per day")
  elif d == "V":
    bb = mma + 1.9
    print("you need to consume", bb, "per day")
  
if ques == "M":
  wwa = float(66.47 + (13.75 * w) + (5.003 * h) - (6.755 * o))
  if d == "S":
    bo = wwa + 1.2
    print("you need to consume", bo, "per day")
  elif d == "L":
    ba = wwa + 1.375
    print("you need to consume", ba, "per day")
  elif d == "M":
    be = wwa + 1.55
    print("you need to consume", be, "per day")
  elif d == "A":
    bi = wwa + 1.725
    print("you need to consume", bi, "per day")
  elif d == "V":
    bb = wwa + 1.9
    print("you need to consume", bb, "per day")

  
  
